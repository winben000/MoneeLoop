import type { Metadata } from 'next';
import PricingClient from './pricing-client';

export const metadata: Metadata = {
  title: 'MoneeLoop Premium — Bảng giá',
  description: 'Chọn gói MoneeLoop Premium theo tháng hoặc theo năm và tiết kiệm 30%.',
  openGraph: {
    title: 'MoneeLoop Premium — Bảng giá',
    description: 'Học không giới hạn với gói tháng 99.000₫ hoặc tiết kiệm 30% khi chọn gói năm.',
    images: [],
  },
  twitter: {
    card: 'summary',
    title: 'MoneeLoop Premium — Bảng giá',
    description: 'Học không giới hạn với gói tháng 99.000₫ hoặc tiết kiệm 30% khi chọn gói năm.',
    images: [],
  },
};

export default function PricingPage() {
  return <PricingClient />;
}
