'use client';

import Link from 'next/link';

export default function PricingClient() {
  return (
    <main className="pricing-page">
      <header className="pricing-topbar">
        <Link className="brand pricing-brand" href="/">
          <span className="brand-mark"><i /><i /></span>
          <span>Monee<span>Loop</span></span>
        </Link>
        <Link className="back-link pricing-back" href="/">← Về trang chính</Link>
      </header>

      <section className="pricing-hero">
        <p className="eyebrow">MONEELOOP PREMIUM</p>
        <h1>Đầu tư nhỏ cho một<br />thói quen lớn.</h1>
        <p>Học không giới hạn, mở toàn bộ LoopInsight và nhận gấp đôi LoopToken sau mỗi bài.</p>
      </section>

      <section className="pricing-page-plans" aria-label="Các gói MoneeLoop Premium">
        <article className="standalone-plan">
          <small>LINH HOẠT</small>
          <h2>Hàng tháng</h2>
          <div className="price"><strong>99.000₫</strong><span>/ tháng</span></div>
          <ul>
            <li>Toàn bộ bài học Premium</li>
            <li>LoopInsight chuyên sâu</li>
            <li>Nhận x2 LoopToken</li>
            <li>Hủy bất cứ lúc nào</li>
          </ul>
          <button onClick={() => alert('Bạn đã chọn gói 99.000₫/tháng')}>Chọn gói tháng</button>
        </article>

        <article className="standalone-plan featured-plan">
          <em>TIẾT KIỆM 30%</em>
          <small>TỐT NHẤT</small>
          <h2>Hàng năm</h2>
          <div className="price"><strong>831.600₫</strong><span>/ năm</span></div>
          <p className="equivalent">Tương đương 69.300₫/tháng</p>
          <ul>
            <li>Đầy đủ quyền lợi Premium</li>
            <li>Tiết kiệm 356.400₫ mỗi năm</li>
            <li>Nhận x2 LoopToken</li>
            <li>Huy hiệu thành viên năm</li>
          </ul>
          <button onClick={() => alert('Bạn đã chọn gói năm — tiết kiệm 30%')}>Chọn gói năm</button>
        </article>
      </section>

      <p className="pricing-assurance">Thanh toán an toàn · Có thể hủy bất cứ lúc nào · Hỗ trợ thành viên 7 ngày/tuần</p>
    </main>
  );
}
