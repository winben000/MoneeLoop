'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';

const formatVnd = (value: number) => new Intl.NumberFormat('vi-VN').format(value) + '₫';
const progressKey = 'moneeloop:test-progress';
const lessonId = 'emergency-fund-101';

export default function LessonClient() {
  const [monthlyExpense, setMonthlyExpense] = useState(5000000);
  const [months, setMonths] = useState(3);
  const [quiz, setQuiz] = useState('');
  const [progress, setProgress] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);
  const target = useMemo(() => monthlyExpense * months, [monthlyExpense, months]);
  const complete = progress === 100;

  useEffect(() => {
    try {
      const stored = JSON.parse(sessionStorage.getItem(progressKey) || '{}');
      setProgress(Number(stored[lessonId]) || 0);
    } catch {
      setProgress(0);
    }
  }, []);

  const saveProgress = (nextProgress: number) => {
    setProgress(nextProgress);
    try {
      const stored = JSON.parse(sessionStorage.getItem(progressKey) || '{}');
      sessionStorage.setItem(progressKey, JSON.stringify({ ...stored, [lessonId]: nextProgress }));
      window.dispatchEvent(new Event('moneeloop-progress'));
    } catch {
      // Progress still works in memory when browser storage is unavailable.
    }
  };

  const advanceProgress = (milestone: number) => saveProgress(Math.max(progress, milestone));
  const completeLesson = () => {
    saveProgress(100);
    setShowCelebration(true);
  };
  const restartLesson = () => {
    saveProgress(0);
    setQuiz('');
    setShowCelebration(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  return (
    <main className="lesson-page">
      <section className="lesson-opening">
        <header className="lesson-topbar"><Link className="landing-logo lesson-brand" href="/" aria-label="Về trang chủ MoneeLoop"><span className="landing-logo-mark"><i /><i /></span><span>Monee<b>Loop</b></span></Link><div className="lesson-progress" aria-live="polite"><span>Tiến độ bài học</span><div><i style={{width: `${progress}%`}} /></div><b>{progress}%</b></div><div className="lesson-account"><div className="landing-token" aria-label="1.280 LoopToken"><span>✦</span><b>1.280</b></div><Link className="landing-avatar" href="/learn" aria-label="Mở hồ sơ Thu Hà">HA</Link></div></header>
        <section className="lesson-hero"><div className="lesson-hero-copy"><Link className="lesson-return" href="/learn#loopcourse">← Về lộ trình</Link><p className="course-tag">LOOPCOURSE · TÀI CHÍNH CÁ NHÂN</p><h1>Quỹ khẩn cấp 101</h1><p>Một lớp đệm nhỏ để những bất ngờ lớn không làm lệch hướng kế hoạch tài chính của bạn.</p><div className="hero-meta"><span>◷ 8 phút</span><span>▤ 5 phần</span><span>✦ +40 token</span></div></div><div className="lesson-hero-art" aria-hidden="true"><div className="lesson-visual-top"><span>BÀI HỌC ĐANG HỌC</span><b>{progress}%</b></div><div className="shield-orb">◎<small>AN TOÀN</small></div><i className="lesson-ring one" /><i className="lesson-ring two" /><div className="lesson-visual-card"><span>Quỹ an toàn của bạn</span><strong>3 tháng chi tiêu</strong><div><i style={{width: `${progress}%`}} /></div></div></div></section>
      </section>
      <div className="lesson-layout">
        <article className="lesson-article">
          <section id="why"><p className="lesson-kicker">01 · NỀN TẢNG</p><h2>Quỹ khẩn cấp là gì?</h2><p>Đó là khoản tiền chỉ dùng cho những tình huống thật sự bất ngờ: mất thu nhập, viện phí, sửa xe hoặc một việc gia đình cấp bách. Nó không phải tiền du lịch, mua điện thoại mới hay săn một cơ hội đầu tư.</p><div className="lesson-callout"><span>Nguyên tắc đơn giản</span><strong>Dễ rút · Ít biến động · Tách khỏi tiền chi tiêu</strong></div></section>
          <section id="calculate"><p className="lesson-kicker">02 · THỰC HÀNH</p><h2>Tính “con số an tâm” của bạn</h2><p>Bắt đầu bằng chi phí thiết yếu mỗi tháng, sau đó nhân với số tháng bạn muốn được bảo vệ.</p><div className="fund-calculator"><label>Chi phí thiết yếu mỗi tháng<strong>{formatVnd(monthlyExpense)}</strong><input type="range" min="2000000" max="20000000" step="500000" value={monthlyExpense} onChange={e => { setMonthlyExpense(Number(e.target.value)); advanceProgress(25); }} /></label><div className="month-choice"><span>Số tháng dự phòng</span>{[1,3,6].map(value => <button key={value} className={months === value ? 'selected' : ''} onClick={() => { setMonths(value); advanceProgress(25); }}>{value} tháng</button>)}</div><div className="target-result"><span>Mục tiêu quỹ khẩn cấp</span><strong>{formatVnd(target)}</strong><small>{formatVnd(monthlyExpense)} × {months} tháng</small></div></div></section>
          <section id="steps"><p className="lesson-kicker">03 · LỘ TRÌNH</p><h2>Xây quỹ theo ba nấc</h2><div className="step-list"><article><b>01</b><div><h3>Chạm mốc khởi động</h3><p>Để dành một tháng chi phí thiết yếu trước. Mục tiêu đầu tiên nên đủ gần để bạn thấy mình đang tiến lên.</p></div></article><article><b>02</b><div><h3>Tự động hoá mỗi kỳ lương</h3><p>Chuyển tiền sang tài khoản riêng ngay khi nhận lương, trước khi bắt đầu chi tiêu.</p></div></article><article><b>03</b><div><h3>Mở rộng lên 3–6 tháng</h3><p>Tăng mục tiêu nếu thu nhập biến động, có người phụ thuộc hoặc công việc khó thay thế.</p></div></article></div></section>
          <section id="example"><p className="lesson-kicker">04 · VÍ DỤ</p><h2>Kế hoạch của Mai</h2><div className="example-card"><div className="example-avatar">M</div><div><p>Mai mới đi làm, chi phí thiết yếu là <strong>5 triệu đồng/tháng</strong>. Mai chọn quỹ 3 tháng, nên mục tiêu là <strong>15 triệu đồng</strong>.</p><div className="example-math"><span>Tiết kiệm mỗi tháng<strong>1,5 triệu</strong></span><span>Thời gian dự kiến<strong>10 tháng</strong></span><span>Đích đến<strong>15 triệu</strong></span></div></div></div><p className="lesson-note">Mai giữ quỹ trong tài khoản riêng, dễ rút và không dùng để đầu tư vào tài sản biến động.</p></section>
          <section id="quiz"><p className="lesson-kicker">05 · KIỂM TRA NHANH</p><h2>Tình huống nào nên dùng quỹ khẩn cấp?</h2><div className="quiz-options">{[['phone','Mua điện thoại mới đang giảm giá'],['repair','Sửa xe để tiếp tục đi làm'],['trip','Đặt vé cho chuyến du lịch'],['invest','Mua cổ phiếu khi thị trường giảm']].map(([value,label]) => <button key={value} className={quiz === value ? (value === 'repair' ? 'correct' : 'wrong') : ''} onClick={() => { setQuiz(value); if (value === 'repair') advanceProgress(75); }}><i>{quiz === value ? (value === 'repair' ? '✓' : '×') : '○'}</i>{label}</button>)}</div>{quiz && <div className={quiz === 'repair' ? 'quiz-feedback good' : 'quiz-feedback'}>{quiz === 'repair' ? 'Chính xác! Đây là chi phí bất ngờ, cần thiết và ảnh hưởng trực tiếp đến khả năng tạo thu nhập.' : 'Chưa đúng. Quỹ khẩn cấp dành cho nhu cầu bất ngờ và thiết yếu, không phải chi tiêu tuỳ chọn hay đầu tư.'}</div>}</section>
          <section className="lesson-finish"><span>✦</span><div><p className="eyebrow">HOÀN THÀNH BÀI HỌC</p><h2>{complete ? 'Bạn đã nhận 40 LoopToken!' : 'Sẵn sàng giữ vững kế hoạch?'}</h2><p>{complete ? 'Tuyệt vời. Bước tiếp theo là đặt lệnh chuyển tiền tự động đầu tiên.' : 'Đánh dấu hoàn thành để nhận phần thưởng và tiếp tục lộ trình.'}</p></div><button onClick={completeLesson} disabled={complete}>{complete ? 'Đã hoàn thành ✓' : 'Hoàn thành · +40 ✦'}</button></section>
        </article>
        <aside className="lesson-toc"><p>TRONG BÀI NÀY</p><a href="#why">01 · Quỹ khẩn cấp là gì?</a><a href="#calculate">02 · Tính mục tiêu</a><a href="#steps">03 · Ba nấc xây quỹ</a><a href="#example">04 · Ví dụ của Mai</a><a href="#quiz">05 · Kiểm tra nhanh</a><div><span>Ghi nhớ</span><p>Đây là nội dung giáo dục, không phải tư vấn tài chính cá nhân.</p></div></aside>
      </div>
      {showCelebration && <div className="celebration-backdrop" role="presentation" onClick={() => setShowCelebration(false)}><section className="celebration-modal" role="dialog" aria-modal="true" aria-labelledby="celebration-title" onClick={event => event.stopPropagation()}><button className="celebration-close" onClick={() => setShowCelebration(false)} aria-label="Đóng thông báo">×</button><div className="celebration-burst" aria-hidden="true"><i>✦</i><i>●</i><i>◆</i><strong>✓</strong><i>●</i><i>✦</i></div><p className="lesson-kicker">HOÀN THÀNH 100%</p><h2 id="celebration-title">Xuất sắc! Bạn đã hoàn thành bài học.</h2><p>40 LoopToken đã được thêm vào phần thưởng thử nghiệm của bạn. Tiến độ được lưu tạm thời trong phiên này.</p><div className="celebration-actions"><Link href="/learn">Về lộ trình</Link><button onClick={restartLesson}>Học lại từ đầu</button></div></section></div>}
    </main>
  );
}
