import type { Metadata } from 'next';
import LessonClient from './lesson-client';

export const metadata: Metadata = {
  title: 'Quỹ khẩn cấp 101 — MoneeLoop',
  description: 'Bài học mẫu giúp bạn tính và bắt đầu xây quỹ khẩn cấp.',
  openGraph: { title: 'Quỹ khẩn cấp 101 — MoneeLoop', description: 'Bài học mẫu giúp bạn tính và bắt đầu xây quỹ khẩn cấp.', images: [] },
  twitter: { card: 'summary', title: 'Quỹ khẩn cấp 101 — MoneeLoop', description: 'Bài học mẫu giúp bạn tính và bắt đầu xây quỹ khẩn cấp.', images: [] },
};

export default function LessonPage() { return <LessonClient />; }
