'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

const lessons = [
  { id: 'emergency-fund-101', icon: '◎', title: 'Quỹ khẩn cấp 101', track: 'Tài chính cá nhân', time: '8 phút', reward: 40, color: 'mint' },
  { id: 'compound-interest', icon: '↗', title: 'Lãi kép hoạt động thế nào?', track: 'Đầu tư cơ bản', time: '6 phút', reward: 35, color: 'violet' },
  { id: 'bank-fees', icon: '◇', title: 'Đọc bảng phí ngân hàng', track: 'Sản phẩm tài chính', time: '10 phút', reward: 50, color: 'amber' },
];
const nav = [
  { icon: '⌂', label: 'Tổng quan', href: '#top' },
  { icon: '▤', label: 'LoopCourse', href: '#loopcourse' },
  { icon: '⌕', label: 'LoopInsight', href: '#loopinsight' },
  { icon: '◈', label: 'LoopProgram', href: '#loopprogram' },
  { icon: '✦', label: 'Phần thưởng', href: '#rewards' },
];

export default function LearnPage() {
  const router = useRouter();
  const [activeNav, setActiveNav] = useState('Tổng quan');
  const [activeLesson, setActiveLesson] = useState(0);
  const [saved, setSaved] = useState(false);
  const [streak, setStreak] = useState(7);
  const [progress, setProgress] = useState<Record<string, number>>(() => Object.fromEntries(lessons.map(item => [item.id, 0])));
  const lesson = { ...lessons[activeLesson], progress: progress[lessons[activeLesson].id] ?? 0 };
  const greeting = useMemo(() => new Intl.DateTimeFormat('vi-VN', { weekday: 'long' }).format(new Date()), []);
  useEffect(() => {
    const readProgress = () => {
      try {
        const stored = JSON.parse(sessionStorage.getItem('moneeloop:test-progress') || '{}');
        setProgress(Object.fromEntries(lessons.map(item => [item.id, Number(stored[item.id]) || 0])));
      } catch {
        setProgress(Object.fromEntries(lessons.map(item => [item.id, 0])));
      }
    };
    readProgress();
    window.addEventListener('focus', readProgress);
    window.addEventListener('moneeloop-progress', readProgress);
    return () => {
      window.removeEventListener('focus', readProgress);
      window.removeEventListener('moneeloop-progress', readProgress);
    };
  }, []);
  return (
    <main className="app-shell">
      <aside className="sidebar">
        <Link className="brand" href="/" aria-label="Về trang chủ MoneeLoop"><span className="brand-mark"><i /><i /></span><span>Monee<span>Loop</span></span></Link>
        <nav aria-label="Điều hướng chính"><p className="nav-label">Khám phá</p>{nav.map(({icon, label, href}) => <a key={label} href={href} className={activeNav === label ? 'nav-item active' : 'nav-item'} onClick={() => setActiveNav(label)}><span>{icon}</span>{label}</a>)}</nav>
        <div className="upgrade-card"><span className="mini-orbit">✦</span><strong>Mở khóa Premium</strong><p>Học không giới hạn và nhận x2 LoopToken.</p><a className="upgrade-link" href="/pricing">Khám phá ngay</a></div>
        <button className="profile"><span className="avatar">HA</span><span><strong>Thu Hà</strong><small>Level 4 · Tân binh</small></span><b>···</b></button>
      </aside>
      <section className="workspace" id="top">
        <header className="topbar"><Link className="mobile-brand" href="/" aria-label="Về trang chủ">◎</Link><label className="search"><span>⌕</span><input aria-label="Tìm kiếm" placeholder="Tìm bài học, chủ đề, sản phẩm..." /></label><div className="top-actions"><button className="token-pill"><span>✦</span><b>1,280</b> LoopToken</button><button className="icon-button" aria-label="Thông báo">♢<i /></button></div></header>
        <div className="content">
          <div className="welcome-row"><div><p className="eyebrow">{greeting} · Chào buổi sáng</p><h1>Tiếp tục hành trình<br />tự do tài chính.</h1></div><div className="streak-card" onClick={() => setStreak(v => v + 1)} role="button" tabIndex={0}><span className="flame">♨</span><div><strong>{streak} ngày</strong><small>Chuỗi học liên tục</small></div><b>Giữ lửa →</b></div></div>
          <section className="hero-course"><div className="hero-copy"><p className="course-tag">BÀI HỌC ĐANG HỌC</p><h2>{lesson.title}</h2><p>Nắm vững kiến thức nền tảng, áp dụng ngay vào cuộc sống và xây thói quen tài chính lành mạnh.</p><div className="hero-meta"><span>◷ {lesson.time}</span><span>✦ +{lesson.reward} token</span><span>● {lesson.progress}% hoàn thành</span></div><button className="primary-button" onClick={() => activeLesson === 0 ? router.push('/lessons/emergency-fund-101') : alert(`Bài mẫu đang được hoàn thiện: ${lesson.title}`)}>Tiếp tục học <span>→</span></button></div><div className="hero-visual" aria-hidden="true"><div className="planet-ring ring-one" /><div className="planet-ring ring-two" /><div className="coin coin-one">₫</div><div className="coin coin-two">✦</div><div className="hero-badge"><small>Mục tiêu</small><strong>3 tháng chi tiêu</strong><span>▰▰▰▱</span></div><div className="big-orb">{lesson.icon}</div></div></section>
          <section className="section-block anchor-section" id="loopcourse"><div className="section-heading"><div><p className="eyebrow">LOOPCOURSE · LỘ TRÌNH CỦA BẠN</p><h3>Học tiếp hôm nay</h3></div><button>Xem tất cả <span>→</span></button></div><div className="lesson-grid">{lessons.map((item, index) => { const itemProgress = progress[item.id] ?? 0; return <article className={activeLesson === index ? 'lesson-card selected' : 'lesson-card'} key={item.title} onClick={() => { setActiveLesson(index); if (index === 0) router.push('/lessons/emergency-fund-101'); }}><div className={`lesson-art ${item.color}`}><span>{item.icon}</span><em>{itemProgress ? `${itemProgress}%` : '0%'}</em></div><div className="lesson-info"><small>{item.track}</small><h4>{item.title}</h4><div><span>◷ {item.time}</span><span>✦ {item.reward}</span></div><div className="progress"><i style={{ width: `${itemProgress}%` }} /></div>{index === 0 && <span className="sample-label">Xem bài học mẫu →</span>}</div></article>; })}</div></section>
          <div className="bottom-grid"><section className="insight-card anchor-section" id="loopinsight"><div className="section-heading compact"><div><p className="eyebrow">LOOPINSIGHT</p><h3>Hiểu trước khi chọn</h3></div><button className={saved ? 'saved' : ''} onClick={() => setSaved(!saved)}>{saved ? '♥ Đã lưu' : '♡ Lưu'}</button></div><div className="insight-body"><div className="bank-icon">▥</div><div><span className="trend">ĐANG ĐƯỢC QUAN TÂM</span><h4>Gửi tiết kiệm hay mua chứng chỉ quỹ?</h4><p>So sánh lợi suất, mức độ rủi ro và tính thanh khoản trong 5 phút.</p><button onClick={() => alert('Mở bài so sánh LoopInsight')}>Đọc phân tích →</button></div></div></section><section className="challenge-card"><p className="eyebrow">THỬ THÁCH TUẦN</p><h3>Money Reset</h3><p>Ghi lại 5 khoản chi và tìm một khoản có thể tối ưu.</p><div className="challenge-progress empty"><span><b>0</b>/5 khoản</span><div><i /></div></div><button onClick={() => alert('Đã mở thử thách Money Reset')}>Bắt đầu thử thách</button></section></div>
          <section className="program-section anchor-section" id="loopprogram"><div><p className="eyebrow">LOOPPROGRAM · TRẢI NGHIỆM DOANH NGHIỆP</p><h3>Fintech Survival Challenge</h3><p>Giải một case tài chính thực tế cùng mentor, xây ngân sách cho người mới đi làm và trình bày quyết định của bạn.</p><div className="program-meta"><span>05 ngày</span><span>01 mentor session</span><span>+200 LoopToken</span></div><button onClick={() => alert('Bạn đã đăng ký quan tâm chương trình!')}>Xem chương trình →</button></div><div className="program-orbit" aria-hidden="true"><i>01</i><span>Case</span><i>02</i><span>Mentor</span><i>03</i><span>Reward</span></div></section>
          <section className="rewards-section anchor-section" id="rewards"><div className="section-heading"><div><p className="eyebrow">PHẦN THƯỞNG</p><h3>Học tốt, nhận quyền lợi thật</h3></div><div className="reward-balance">✦ <strong>1,280</strong> LoopToken</div></div><div className="reward-grid"><article><span>☕</span><div><h4>Voucher đồ uống</h4><p>Đổi từ 300 token</p></div></article><article><span>▤</span><div><h4>Khoá học Premium</h4><p>Đổi từ 900 token</p></div></article><article><span>♧</span><div><h4>Mentor session</h4><p>Đổi từ 1,200 token</p></div></article></div></section>
        </div>
      </section>
    </main>
  );
}
