import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Không gian học — MoneeLoop',
  description: 'Học tài chính qua bài ngắn, tình huống thực tế và phần thưởng LoopToken.',
};

export default function LearnLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return children;
}
