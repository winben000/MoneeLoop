import type { Metadata } from 'next';
import { Be_Vietnam_Pro, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const display = Plus_Jakarta_Sans({ variable: '--font-display', subsets: ['latin', 'vietnamese'] });
const body = Be_Vietnam_Pro({ variable: '--font-body', subsets: ['latin', 'vietnamese'], weight: ['400', '500', '600', '700'] });

export const metadata: Metadata = {
  title: 'MoneeLoop — Học tài chính, tạo tương lai',
  description: 'Nền tảng giáo dục tài chính Learn-to-Earn dành cho Gen Z.',
  openGraph: {
    title: 'MoneeLoop — Học tài chính, tạo tương lai',
    description: 'Nền tảng giáo dục tài chính Learn-to-Earn dành cho Gen Z.',
    images: [],
  },
  twitter: {
    card: 'summary',
    title: 'MoneeLoop — Học tài chính, tạo tương lai',
    description: 'Nền tảng giáo dục tài chính Learn-to-Earn dành cho Gen Z.',
    images: [],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi">
      <body className={`${display.variable} ${body.variable}`}>
        {children}
      </body>
    </html>
  );
}
