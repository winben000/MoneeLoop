'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';

const loopBrands = ['LoopCourse', 'LoopInsight', 'LoopProgram', 'LoopToken', 'Learn to Earn'];
const topics = ['Quỹ khẩn cấp', 'Chi tiêu thông minh', 'Lãi kép', 'Đầu tư cơ bản', 'Sản phẩm tài chính', 'Case doanh nghiệp'];

function ArrowButton({ href, children, light = false }: { href: string; children: React.ReactNode; light?: boolean }) {
  return <Link className={`landing-cta${light ? ' light' : ''}`} href={href}><span>{children}</span><i aria-hidden="true">→</i></Link>;
}

export default function LandingPage() {
  const [showPricing, setShowPricing] = useState(false);
  const [courseProgress, setCourseProgress] = useState(0);

  useEffect(() => {
    const readProgress = () => {
      try {
        const stored = JSON.parse(sessionStorage.getItem('moneeloop:test-progress') || '{}');
        setCourseProgress(Number(stored['emergency-fund-101']) || 0);
      } catch {
        setCourseProgress(0);
      }
    };
    readProgress();
    window.addEventListener('focus', readProgress);
    window.addEventListener('moneeloop-progress', readProgress);
    return () => {
      window.removeEventListener('focus', readProgress);
      window.removeEventListener('moneeloop-progress', readProgress);
    };
  }, []);

  useEffect(() => {
    if (!showPricing) return;
    const closeOnEscape = (event: KeyboardEvent) => event.key === 'Escape' && setShowPricing(false);
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [showPricing]);

  return (
    <main className="landing-page">
      <section className="landing-screen">
        <nav className="landing-nav" aria-label="Điều hướng trang giới thiệu">
          <Link className="landing-logo" href="/" aria-label="Trang chủ MoneeLoop"><span className="landing-logo-mark"><i /><i /></span><span>Monee<b>Loop</b></span></Link>
          <div className="landing-links"><a href="#product">Sản phẩm</a><a href="#journey">Hành trình</a><a href="#program">Chương trình</a></div>
          <div className="landing-user-actions"><button className="landing-premium-button" onClick={() => setShowPricing(true)}>✦ Premium</button><div className="landing-token" aria-label="1.280 LoopToken"><span>✦</span><b>1.280</b></div><Link className="landing-avatar" href="/learn" aria-label="Mở hồ sơ Thu Hà">HA</Link></div>
        </nav>

        <div className="landing-hero">
          <div className="landing-hero-copy">
            <p className="landing-kicker">TÀI CHÍNH DỄ HIỂU · TIẾN BỘ THẤY ĐƯỢC</p>
            <h1>Kiến thức tài chính.<br />Làm việc cho bạn.</h1>
            <p>Học qua bài ngắn, thử sức với tình huống thật và nhận LoopToken cho từng bước tiến bộ.</p>
            <div className="landing-hero-actions"><ArrowButton href="/lessons/emergency-fund-101" light>Bắt đầu miễn phí</ArrowButton><button className="hero-premium-link" onClick={() => setShowPricing(true)}>Xem MoneeLoop Premium</button></div>
          </div>

          <div className="landing-product-preview" aria-label="Xem trước trải nghiệm học MoneeLoop">
            <div className="preview-top"><span>HÀNH TRÌNH CỦA BẠN</span><b>{courseProgress}%</b></div>
            <div className="preview-orbit"><div className="preview-core">◎<small>QUỸ AN TOÀN</small></div><i /><i /></div>
            <div className="preview-card"><span>BÀI HỌC ĐỀ XUẤT</span><strong>Quỹ khẩn cấp 101</strong><small>8 phút · +40 LoopToken</small><div><i style={{ width: `${courseProgress}%` }} /></div></div>
            <div className="preview-token">✦ <b>+40</b></div>
          </div>

          <div className="landing-marquee" aria-hidden="true"><div className="landing-marquee-track">{[...loopBrands, ...loopBrands].map((name, index) => <span key={`${name}-${index}`}>{name}</span>)}</div></div>
        </div>
      </section>

      <section className="landing-info" id="product">
        <div className="landing-intro">
          <div><p className="landing-kicker dark">GẶP GỠ MONEELOOP</p><h2>Một vòng lặp nhỏ.<br />Một tương lai lớn.</h2><ArrowButton href="/lessons/emergency-fund-101">Khám phá ngay</ArrowButton></div>
          <p>MoneeLoop biến tài chính cá nhân thành một hành trình dễ bắt đầu: hiểu một khái niệm, áp dụng vào đời sống, nhận phản hồi và tiếp tục tiến lên.</p>
        </div>

        <div className="landing-feature-grid" id="journey">
          <article className="feature-wide"><div><span>LOOPCOURSE · BÀI HỌC MẪU</span><h3>Quỹ khẩn cấp 101</h3></div><Link className="landing-course-card" href="/lessons/emergency-fund-101"><div className="landing-course-icon">◎</div><div className="landing-course-info"><span>TÀI CHÍNH CÁ NHÂN</span><strong>Một lớp đệm cho những bất ngờ lớn.</strong><small>8 phút · 5 phần · +40 LoopToken</small><div className="landing-course-progress"><div><i style={{ width: `${courseProgress}%` }} /></div><b>{courseProgress}%</b></div></div><em>→</em></Link><p>Bài học có công cụ tính quỹ, ví dụ thực tế và bài kiểm tra nhanh. Tiến độ được lưu tạm thời trong phiên học.</p></article>
          <article className="feature-dark"><span>LOOPINSIGHT</span><h3>Hiểu trước<br />khi chọn.</h3><p>So sánh sản phẩm tài chính bằng ngôn ngữ rõ ràng và các tiêu chí thực tế.</p></article>
          <article className="feature-lime"><span>LOOPTOKEN</span><h3>Tiến bộ<br />có phần thưởng.</h3><p>Hoàn thành bài học và thử thách để tích lũy quyền lợi thật.</p></article>
        </div>
      </section>

      <section className="landing-topics" aria-label="Các chủ đề học"><div><p>KIẾN THỨC ĐI CÙNG BẠN</p></div><div className="topics-window"><div className="topics-track">{[...topics, ...topics].map((topic, index) => <span key={`${topic}-${index}`}>{topic}</span>)}</div></div></section>

      <section className="landing-practice" id="program">
        <div className="practice-copy"><p className="landing-kicker dark">MONEELOOP TRONG THỰC TẾ</p><h2>Học để<br />làm được.</h2><p>Từ quỹ khẩn cấp đầu tiên đến một case doanh nghiệp cùng mentor—mỗi trải nghiệm đều dẫn tới một quyết định tài chính tốt hơn.</p></div>
        <div className="practice-card">
          <div className="practice-content"><p>LOOPPROGRAM · CASE THỰC TẾ</p><h3>Fintech Survival Challenge</h3><span>05 ngày · 01 mentor session · +200 LoopToken</span><ArrowButton href="/learn#loopprogram" light>Xem chương trình</ArrowButton></div>
          <div className="practice-steps" aria-hidden="true"><i>01<small>Hiểu case</small></i><i>02<small>Gặp mentor</small></i><i>03<small>Trình bày</small></i></div>
        </div>
      </section>

      <footer className="landing-footer"><Link className="landing-logo" href="/"><span className="landing-logo-mark"><i /><i /></span><span>Monee<b>Loop</b></span></Link><p>Học tài chính. Tạo tương lai.</p><button onClick={() => setShowPricing(true)}>Xem MoneeLoop Premium →</button></footer>

      {showPricing && <div className="premium-popup-backdrop" role="presentation" onClick={() => setShowPricing(false)}><section className="premium-popup" role="dialog" aria-modal="true" aria-labelledby="premium-popup-title" onClick={event => event.stopPropagation()}><button className="premium-popup-close" onClick={() => setShowPricing(false)} aria-label="Đóng bảng giá">×</button><div className="premium-popup-heading"><p className="landing-kicker dark">MONEELOOP PREMIUM</p><h2 id="premium-popup-title">Đầu tư nhỏ cho một thói quen lớn.</h2><p>Học không giới hạn, mở toàn bộ LoopInsight và nhận gấp đôi LoopToken sau mỗi bài.</p></div><div className="premium-popup-grid"><article className="standalone-plan"><small>LINH HOẠT</small><h2>Hàng tháng</h2><div className="price"><strong>99.000₫</strong><span>/ tháng</span></div><ul><li>Toàn bộ bài học Premium</li><li>LoopInsight chuyên sâu</li><li>Nhận x2 LoopToken</li><li>Hủy bất cứ lúc nào</li></ul><button onClick={() => alert('Bạn đã chọn gói 99.000₫/tháng')}>Chọn gói tháng</button></article><article className="standalone-plan featured-plan"><em>TIẾT KIỆM 30%</em><small>TỐT NHẤT</small><h2>Hàng năm</h2><div className="price"><strong>831.600₫</strong><span>/ năm</span></div><p className="equivalent">Tương đương 69.300₫/tháng</p><ul><li>Đầy đủ quyền lợi Premium</li><li>Tiết kiệm 356.400₫ mỗi năm</li><li>Nhận x2 LoopToken</li><li>Huy hiệu thành viên năm</li></ul><button onClick={() => alert('Bạn đã chọn gói năm — tiết kiệm 30%')}>Chọn gói năm</button></article></div></section></div>}
    </main>
  );
}
